#include "computer.h"

using namespace std;

Computer::Computer(shared_ptr<Eyes> eye) : eye{eye} {}
