#include "view.h"

int View::getBoardSize() const { return boardSize; }
