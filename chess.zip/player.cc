#include "player.h"

int Player::getScore() const { return score; }
